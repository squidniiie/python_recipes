from recipe_app import app
from recipe_app.controllers import recipes
from recipe_app.controllers import chefs

if __name__ == "__main__":
    app.run(debug=True)
